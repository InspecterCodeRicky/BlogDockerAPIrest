<?php


$Routes = array();
// var_dump($_SERVER["REQUEST_URI"]);

/*
 * We define the BASEDIR. This is the directory that How is stored in. This constant
 * will eventually be set by the installer when it is created.
*/
define( 'BASEDIR', '' );